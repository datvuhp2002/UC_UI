"use strict";exports.id=737,exports.ids=[737],exports.modules={86465:(e,t,n)=>{n.d(t,{Z:()=>j});var r=n(28964),a=n(61929),o=n(63574),i=n(51861),l=n(14759),s=n(9380),d=n(65089),u=n(59537),f=n(17269),p=n(1358);function c(e){return(0,p.ZP)("MuiSkeleton",e)}(0,f.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var h=n(97247);let m=e=>{let{classes:t,variant:n,animation:r,hasChildren:a,width:i,height:l}=e;return(0,o.Z)({root:["root",n,r,a&&"withChildren",a&&!i&&"fitContent",a&&!l&&"heightAuto"]},c,t)},y=(0,l.F4)`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`,b=(0,l.F4)`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`,g="string"!=typeof y?(0,l.iv)`
        animation: ${y} 2s ease-in-out 0.5s infinite;
      `:null,v="string"!=typeof b?(0,l.iv)`
        &::after {
          animation: ${b} 2s linear 0.5s infinite;
        }
      `:null,x=(0,s.default)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,t)=>{let{ownerState:n}=e;return[t.root,t[n.variant],!1!==n.animation&&t[n.animation],n.hasChildren&&t.withChildren,n.hasChildren&&!n.width&&t.fitContent,n.hasChildren&&!n.height&&t.heightAuto]}})((0,d.Z)(({theme:e})=>{let t=String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1]||"px",n=parseFloat(e.shape.borderRadius);return{display:"block",backgroundColor:e.vars?e.vars.palette.Skeleton.bg:(0,i.Fq)(e.palette.text.primary,"light"===e.palette.mode?.11:.13),height:"1.2em",variants:[{props:{variant:"text"},style:{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${n}${t}/${Math.round(n/.6*10)/10}${t}`,"&:empty:before":{content:'"\\00a0"'}}},{props:{variant:"circular"},style:{borderRadius:"50%"}},{props:{variant:"rounded"},style:{borderRadius:(e.vars||e).shape.borderRadius}},{props:({ownerState:e})=>e.hasChildren,style:{"& > *":{visibility:"hidden"}}},{props:({ownerState:e})=>e.hasChildren&&!e.width,style:{maxWidth:"fit-content"}},{props:({ownerState:e})=>e.hasChildren&&!e.height,style:{height:"auto"}},{props:{animation:"pulse"},style:g||{animation:`${y} 2s ease-in-out 0.5s infinite`}},{props:{animation:"wave"},style:{position:"relative",overflow:"hidden",WebkitMaskImage:"-webkit-radial-gradient(white, black)","&::after":{background:`linear-gradient(
                90deg,
                transparent,
                ${(e.vars||e).palette.action.hover},
                transparent
              )`,content:'""',position:"absolute",transform:"translateX(-100%)",bottom:0,left:0,right:0,top:0}}},{props:{animation:"wave"},style:v||{"&::after":{animation:`${b} 2s linear 0.5s infinite`}}}]}})),j=r.forwardRef(function(e,t){let n=(0,u.i)({props:e,name:"MuiSkeleton"}),{animation:r="pulse",className:o,component:i="span",height:l,style:s,variant:d="text",width:f,...p}=n,c={...n,animation:r,component:i,variant:d,hasChildren:!!p.children},y=m(c);return(0,h.jsx)(x,{as:i,ref:t,className:(0,a.Z)(y.root,o),ownerState:c,...p,style:{width:f,height:l,...s}})})},2761:(e,t,n)=>{n.d(t,{default:()=>a.a});var r=n(27692),a=n.n(r)},27692:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return o}});let r=n(20352);n(97247),n(28964);let a=r._(n(22404));function o(e,t){var n;let r={loading:e=>{let{error:t,isLoading:n,pastDelay:r}=e;return null}};"function"==typeof e&&(r.loader=e);let o={...r,...t};return(0,a.default)({...o,modules:null==(n=o.loadableGenerated)?void 0:n.modules})}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},99304:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"BailoutToCSR",{enumerable:!0,get:function(){return a}});let r=n(47173);function a(e){let{reason:t,children:n}=e;throw new r.BailoutToCSRError(t)}},22404:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return d}});let r=n(97247),a=n(28964),o=n(99304),i=n(24146);function l(e){return{default:e&&"default"in e?e.default:e}}let s={loader:()=>Promise.resolve(l(()=>null)),loading:null,ssr:!0},d=function(e){let t={...s,...e},n=(0,a.lazy)(()=>t.loader().then(l)),d=t.loading;function u(e){let l=d?(0,r.jsx)(d,{isLoading:!0,pastDelay:!0,error:null}):null,s=t.ssr?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(i.PreloadCss,{moduleIds:t.modules}),(0,r.jsx)(n,{...e})]}):(0,r.jsx)(o.BailoutToCSR,{reason:"next/dynamic",children:(0,r.jsx)(n,{...e})});return(0,r.jsx)(a.Suspense,{fallback:l,children:s})}return u.displayName="LoadableComponent",u}},24146:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"PreloadCss",{enumerable:!0,get:function(){return o}});let r=n(97247),a=n(54580);function o(e){let{moduleIds:t}=e,n=(0,a.getExpectedRequestStore)("next/dynamic css"),o=[];if(n.reactLoadableManifest&&t){let e=n.reactLoadableManifest;for(let n of t){if(!e[n])continue;let t=e[n].files.filter(e=>e.endsWith(".css"));o.push(...t)}}return 0===o.length?null:(0,r.jsx)(r.Fragment,{children:o.map(e=>(0,r.jsx)("link",{precedence:"dynamic",rel:"stylesheet",href:n.assetPrefix+"/_next/"+encodeURI(e),as:"style"},e))})}}};